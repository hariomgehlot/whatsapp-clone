import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-right-chat-container',
  templateUrl: './right-chat-container.component.html',
  styleUrls: ['./right-chat-container.component.scss']
})
export class RightChatContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
