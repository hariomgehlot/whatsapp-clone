import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-right-chat-header',
  templateUrl: './right-chat-header.component.html',
  styleUrls: ['./right-chat-header.component.scss']
})
export class RightChatHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
